/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.vizsga.vizsgaprojekt.service;

import com.vizsga.vizsgaprojekt.config.JWT;
import com.vizsga.vizsgaprojekt.modell.Courses;
import com.vizsga.vizsgaprojekt.modell.Users;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author asd
 */
public class CoursesService {
    private Courses layer = new Courses();

    
    public JSONObject addCourses(Courses c, String jwt){
        JSONObject toReturn = new JSONObject();
        String status = "success";
        int statusCode = 200;
        
        if(JWT.validateJWT(jwt) != 1){ //Megvizsgálom, hogy érvényes a token
            status = "IvalidToken";
            statusCode = 404;
        }else if(!JWT.isAdmin(jwt)){ // Csak admin felhasználók adhatnak hozzá kurzust
            status = "Unauthorized";
            statusCode = 403;
        }else{
            if(c.getName().isEmpty()){//Ha a kurzus nevét üresen hagyák
                status = "CoursesNameEmpty";
                statusCode = 417;
            }else{
                if(c.getDescription().isEmpty()){//Ha a kurzus leírása üres
                    status = "CoursesDescriptionEmpty";
                    statusCode = 417;
                }else{
                    boolean addSuccess = layer.addCourses(c);//Sikeres kurzus hozzáadás
                    if(!addSuccess){//Ha a kurzust nem sikerült hozzá adni
                        status = "fail";
                        statusCode = 417;
                    }
                }
            }
        }
        
        
        
        toReturn.put("status", status);
        toReturn.put("statusCode", statusCode);
        return toReturn;
    }
    
    public JSONObject getAllCourse(){
        JSONObject toReturn = new JSONObject();
        String status = "success";
        int statusCode = 200;
        List<Courses> modelResult = layer.getAllCourse();
        
        if(modelResult == null){
            status = "ModelException";
            statusCode = 500;
        }else if(modelResult.isEmpty()){
            status = "NoCourseFound";
            statusCode = 417;
        }else{
            JSONArray result = new JSONArray();
            
            for(Courses actualCourses : modelResult){
                JSONObject toAdd = new JSONObject();
                
                toAdd.put("id", actualCourses.getId());
                toAdd.put("name", actualCourses.getName());
                toAdd.put("description", actualCourses.getDescription());
                toAdd.put("isDeleted", actualCourses.getIsDeleted());
                toAdd.put("createdAt", actualCourses.getCreatedAt());
                toAdd.put("deletedAt", actualCourses.getDeletedAt());
                
                result.put(toAdd);
            }
            toReturn.put("result", result);
        }
        
        toReturn.put("status", status);
        toReturn.put("statusCode", statusCode);
        return toReturn;
    }
    
    public JSONObject getCourseById(Integer id){
        JSONObject toReturn = new JSONObject();
        String status = "success";
        int statusCode = 200;
        Courses modelResult = new Courses(id);
        
        if(modelResult.getId() == null){
            status = "CourseNotFound";
            statusCode = 417;
        }else{
            JSONObject course = new JSONObject();
            
            course.put("id", modelResult.getId());
            course.put("name", modelResult.getName());
            course.put("description", modelResult.getDescription());
            course.put("isDeleted", modelResult.getIsDeleted());
            course.put("createdAt", modelResult.getCreatedAt());
            course.put("deletedAt", modelResult.getDeletedAt());
            
            toReturn.put("result", course);
            
        }
        
        toReturn.put("status", status);
        toReturn.put("statusCode", statusCode);
        return toReturn;
    }
    
}
