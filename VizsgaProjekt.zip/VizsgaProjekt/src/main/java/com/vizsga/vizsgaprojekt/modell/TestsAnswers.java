/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.vizsga.vizsgaprojekt.modell;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.ParameterMode;
import javax.persistence.Persistence;
import javax.persistence.StoredProcedureQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author asd
 */
@Entity
@Table(name = "tests_answers")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TestsAnswers.findAll", query = "SELECT t FROM TestsAnswers t"),
    @NamedQuery(name = "TestsAnswers.findById", query = "SELECT t FROM TestsAnswers t WHERE t.id = :id"),
    @NamedQuery(name = "TestsAnswers.findByTestsId", query = "SELECT t FROM TestsAnswers t WHERE t.testsId = :testsId"),
    @NamedQuery(name = "TestsAnswers.findByAnswer", query = "SELECT t FROM TestsAnswers t WHERE t.answer = :answer"),
    @NamedQuery(name = "TestsAnswers.findByValideAnswer", query = "SELECT t FROM TestsAnswers t WHERE t.valideAnswer = :valideAnswer"),
    @NamedQuery(name = "TestsAnswers.findByIsDeleted", query = "SELECT t FROM TestsAnswers t WHERE t.isDeleted = :isDeleted"),
    @NamedQuery(name = "TestsAnswers.findByCreatedAt", query = "SELECT t FROM TestsAnswers t WHERE t.createdAt = :createdAt"),
    @NamedQuery(name = "TestsAnswers.findByDeletedAt", query = "SELECT t FROM TestsAnswers t WHERE t.deletedAt = :deletedAt")})
public class TestsAnswers implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Column(name = "tests_id")
    private int testsId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "answer")
    private String answer;
    @Basic(optional = false)
    @NotNull
    @Column(name = "valide_answer")
    private boolean valideAnswer;
    @Basic(optional = false)
    @NotNull
    @Column(name = "is_deleted")
    private boolean isDeleted;
    @Basic(optional = false)
    @NotNull
    @Column(name = "created_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;
    @Column(name = "deleted_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedAt;

    private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.vizsga_VizsgaProjekt_war_1.0-SNAPSHOTPU");

    public TestsAnswers() {
    }

    public TestsAnswers(Integer id) {
        EntityManager em = emf.createEntityManager();
        
        try{
            TestsAnswers ta = em.find(TestsAnswers.class, id);
            
            this.id = ta.getId();
            this.testsId = ta.getTestsId();
            this.answer = ta.getAnswer();
            this.valideAnswer = ta.getValideAnswer();
            this.isDeleted = ta.getIsDeleted();
            this.createdAt = ta.getCreatedAt();
            this.deletedAt = ta.getDeletedAt();
            
            
        } catch (Exception e) {
            System.err.println("Hiba: " + e.getLocalizedMessage());
        }finally{
            em.clear();
            em.close();
        }
    }

    public TestsAnswers(Integer id, int testsId, String answer, boolean valideAnswer, boolean isDeleted, Date createdAt, Date deletedAt) {
        this.id = id;
        this.testsId = testsId;
        this.answer = answer;
        this.valideAnswer = valideAnswer;
        this.isDeleted = isDeleted;
        this.createdAt = createdAt;
        this.deletedAt = deletedAt;
    }
    
    public  TestsAnswers(int testsId, String answer, boolean valideAnswer){
        this.testsId = testsId;
        this.answer = answer;
        this.valideAnswer = valideAnswer;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getTestsId() {
        return testsId;
    }

    public void setTestsId(int testsId) {
        this.testsId = testsId;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public boolean getValideAnswer() {
        return valideAnswer;
    }

    public void setValideAnswer(boolean valideAnswer) {
        this.valideAnswer = valideAnswer;
    }

    public boolean getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Date getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(Date deletedAt) {
        this.deletedAt = deletedAt;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TestsAnswers)) {
            return false;
        }
        TestsAnswers other = (TestsAnswers) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.vizsga.vizsgaprojekt.modell.TestsAnswers[ id=" + id + " ]";
    }
    
    public Boolean addTestsAnswers (TestsAnswers ta){
        EntityManager em = emf.createEntityManager();
        
        try{
            StoredProcedureQuery spq = em.createStoredProcedureQuery("addTestsAnswers");
            
            spq.registerStoredProcedureParameter("idIN", Integer.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("answerIN", String.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("validIN", Boolean.class, ParameterMode.IN);
            
            spq.setParameter("idIN", ta.getTestsId());
            spq.setParameter("answerIN", ta.getAnswer());
            spq.setParameter("validIN", ta.getValideAnswer());
            
            spq.execute();
            
            return true;
        } catch (Exception e) {
            System.err.println("Hiba"+e.getLocalizedMessage());
            return false;
        }finally{
            em.clear();
            em.close();
        }
    }
    
}
